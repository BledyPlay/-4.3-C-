﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int choice;

        do
        {
            Console.WriteLine("Выберите задание:");
            Console.WriteLine("1. Вывести 5 чисел по порядку начиная с числа 3");
            Console.WriteLine("2. Протабулировать функцию y = cos(x^2) на интервале [-π/4, π/4]");
            Console.WriteLine("3. Ввести числа до тех пор, пока шаг не будет равен 4");
            Console.WriteLine("4. Выполнить цикл до тех пор, пока k не станет меньше n");
            Console.WriteLine("5. Возвести каждое число от 0 до 9 в квадрат");
            Console.WriteLine("6. Оператор a=0. 10 раз нужно увеличить число на 5 и вывести числа, кратные 10, и их сумму");
            Console.WriteLine("7. С шагом 10 вычислить сумму чисел а и б");
            Console.WriteLine("8. Выводить с клавиатуры числа до тех пор, пока не попадется число 10");
            Console.WriteLine("9. Вычислить y = ∑(i^2 + 1) / i от 1 до 15");
            Console.WriteLine("10. Найти факториал 8!");
            Console.WriteLine("0. Выход");

            choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    PrintNumbers();
                    break;
                case 2:
                    TabulateFunction();
                    break;
                case 3:
                    InputNumbers();
                    break;
                case 4:
                    LoopUntilKLessThanN();
                    break;
                case 5:
                    SquareNumbers();
                    break;
                case 6:
                    IncreaseNumberAndFindMultiples();
                    break;
                case 7:
                    SumWithStep();
                    break;
                case 8:
                    InputNumbersUntilTen();
                    break;
                case 9:
                    CalculateY();
                    break;
                case 10:
                    CalculateFactorial();
                    break;
                case 0:
                    Console.WriteLine("Программа завершена.");
                    break;
                default:
                    Console.WriteLine("Неверный выбор. Попробуйте снова.");
                    break;
            }

            Console.WriteLine();
        } while (choice != 0);
    }

    static void PrintNumbers()
    {
        int startNumber = 3;
        int count = 5;

        for (int i = 0; i < count; i++)
        {
            Console.WriteLine(startNumber + i);
        }
    }

    static void TabulateFunction()
    {
        double start_x = -Math.PI / 4;
        double end_x = Math.PI / 4;
        double step = 0.1;

        double x = start_x;
        while (x <= end_x)
        {
            double y = Math.Cos(Math.Pow(x, 2));
            Console.WriteLine($"x = {x}, y = {y}");
            x += step;
        }
    }

    static void InputNumbers()
    {
        int step = 0;
        while (step != 4)
        {
            Console.Write("Введите число: ");
            step = Convert.ToInt32(Console.ReadLine());
        }
    }

    static void LoopUntilKLessThanN()
    {
        int n = 13;
        int k = 90;
        int step = 10;
        while (k >= n)
        {
            Console.WriteLine($"k = {k}");
            k -= step;
        }
    }

    static void SquareNumbers()
    {
        for (int i = 0; i <= 9; i++)
        {
            int square = i * i;
            Console.WriteLine($"{i}^2 = {square}");
        }
    }

    static void IncreaseNumberAndFindMultiples()
    {
        int a = 0;
        int sum = 0;
        for (int i = 0; i < 10; i++)
        {
            a += 5;
            Console.WriteLine(a);
            if (a % 10 == 0)
            {
                sum += a;
            }
        }
        Console.WriteLine("Сумма чисел, кратных 10: " + sum);
    }
    static void SumWithStep()
    {
        int a = 0;
        int b = 0;
        int sum = 0;
        for (int i = 0; i <= 100; i += 10)
        {
            a += i;
            b += i + 1;
            sum = a + b;
        }
        Console.WriteLine("Сумма чисел а и б: " + sum);
    }
    static void InputNumbersUntilTen()
    {
        int number;
        do
        {
            Console.WriteLine("Введите число:");
            number = Convert.ToInt32(Console.ReadLine());
        } while (number != 10);
    }
    static void CalculateY()
    {
        double y = 0;
        for (int i = 1; i <= 15; i++)
        {
            y += (i * i + 1) / (double)i;
        }
        Console.WriteLine("Значение y: " + y);
    }
    static void CalculateFactorial()
    {
        int n = 8;
        int factorial = 1;
        for (int i = 1; i <= n; i++)
        {
            factorial *= i;
        }
        Console.WriteLine("Факториал числа 8!: " + factorial);
    }
}